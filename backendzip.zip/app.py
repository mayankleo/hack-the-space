from flask import Flask, jsonify, request
import psycopg2
from flask_cors import CORS
import random

con = psycopg2.connect(database="postgres",  user="postgres", password="13552089", host="localhost", port="5432")
app = Flask(__name__)
CORS(app, origins=['*'])

@app.route('/')
def hello_world():
    data=[]
    comm = con.cursor()
    comm.execute("SELECT * FROM logindb")
    for i in comm.fetchall():
        data.append({"name":i[1],"username":i[0],"password":i[2]})
    return data


@app.route('/ques')
def getques():
    # data=[]
    # comm = con.cursor()
    # comm.execute("SELECT * FROM questionset")
    # for i in comm.fetchall():
    #     data.append({"chapter":i[0],"question":i[1],"op1":i[2],"op2":i[3],"op3":i[4],"op4":i[5],"correct":i[6],"subject":i[7],"qid":i[8]})
    # return data
    data=[]
    comm = con.cursor()
    comm.execute("SELECT * FROM tempques")
    for i in comm.fetchall():
        data.append({"question":i[0],"op1":i[1],"op2":i[2],"op3":i[3],"op4":i[4],"correct":i[5],"qid":i[6]})
    return data

@app.route('/login', methods=['POST'])
def login_handler():
    if request.method == 'POST':
        username = request.json['username']
        password = request.json['password']
        print(request.json)
        data=[]
        comm = con.cursor()
        query = "SELECT * FROM logindb where loguser='"+username+"' and logpass='"+password+"';"
        print(query)
        comm.execute(query)
        for i in comm.fetchall():
            data.append({"name":i[1],"username":i[0],"password":i[2]})
        print(data)
        if data:
            return jsonify("ok"), 200 
        else:
            return jsonify("error"), 400 



@app.route('/plan', methods=['POST'])
def plan_handler():
    if request.method == 'POST':
        qno = request.json['questions']
        subject = request.json['subject']
        chapter = request.json['chapter']
        # print(request.json)
        data=[]
        comm = con.cursor()
        query = "SELECT * FROM questionset where subject='"+subject+"' and chapter='"+chapter+"';"
        # print(query)
        comm.execute(query)
        for i in comm.fetchall():
            data.append({"question":i[1 ],"op1":i[2],"op2":i[3],"op3":i[4],"op4":i[5],"correct":i[6],"qid":i[8]})
        # print(data)
        random.shuffle(data)

        comm.execute("DELETE FROM tempques;")
        con.commit()

        for i in range(int(qno)):
            print(data[i])
            q="INSERT INTO public.tempques(question, option_a, option_b, option_c, option_d, correctans, qid) VALUES ('"+data[i]['question']+"', '"+data[i]['op1']+"', '"+data[i]['op2']+"', '"+data[i]['op3']+"', '"+data[i]['op4']+"', '"+data[i]['correct']+"', '"+data[i]['qid']+"');"
            print(q)
            comm.execute(q)
            con.commit()

        if data:
            return jsonify("ok"), 200 
        else:
            return jsonify("error"), 400 



if __name__ == '__main__':
    app.run(host='192.168.5.129', port=5002)