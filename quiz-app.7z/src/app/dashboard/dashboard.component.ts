import { Component } from '@angular/core';
import { ApisService } from '../apis.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  data: any
  constructor(private ApisService: ApisService) {
    // this.ApisService.getusers().subscribe(response => {
    //     this.data = response; 
    //     console.log(this.data);
    //   }
    // );
  }

  
  

}
