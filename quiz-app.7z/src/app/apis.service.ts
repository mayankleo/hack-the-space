import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ApisService {
  constructor(private http: HttpClient) { }

  loginuser(data: any):Observable<any>{
    return this.http.post<any>(`http://192.168.5.129:5002/login`, data);
  }
  sendplan(data: any):Observable<any>{
    return this.http.post<any>(`http://192.168.5.129:5002/plan`, data);
  }
  getusers():Observable<any>{
    return this.http.get(`http://192.168.5.129:5002`);
  }
  getques():Observable<any>{
    return this.http.get(`http://192.168.5.129:5002/ques`);
  }
}