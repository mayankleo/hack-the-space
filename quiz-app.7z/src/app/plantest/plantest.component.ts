import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ApisService } from '../apis.service';

@Component({
  selector: 'app-plantest',
  templateUrl: './plantest.component.html',
  styleUrls: ['./plantest.component.scss']
})
export class PlantestComponent {
  planForm: FormGroup;

  triedSubmitting: boolean;
  get questions() { return this.planForm.controls['questions']; }
  get chapter() { return this.planForm.controls['chapter']; }
  get subject() { return this.planForm.controls['subject']; }

  constructor(private formBuilder: FormBuilder, private ApisService: ApisService, private router: Router) {
    this.triedSubmitting = false;
    this.planForm = this.formBuilder.group({
      questions: ['', [Validators.required]],
      chapter: ['', [Validators.required]],
      subject: ['', [Validators.required]]
    });
  }

  sendData() {
    console.log(this.planForm.value);
    this.ApisService.sendplan(this.planForm.value)
    .subscribe(data => { 
      console.log(' succesful');
       }, err => { console.log(' failed'); })
  }
}
