import { Component } from '@angular/core';
import { ApisService } from '../apis.service';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.scss']
})
export class TestComponent {
  data: any
  s1: string = '';
  s2: string = '';
  s3: string = '';
  s4: string = '';
  s5: string = '';

  constructor(private ApisService: ApisService,) {
    this.ApisService.getques().subscribe(response => {
        this.data = response; 
        console.log(this.data);
      }
    );
  }

  send(){
    let a = [this.s1,this.s2,this.s3,this.s4,this.s4]
    console.log(a);
  }
}
