import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ApisService } from '../apis.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loginForm: FormGroup;

  triedSubmitting: boolean;
  get username() { return this.loginForm.controls['username']; }
  get password() { return this.loginForm.controls['password']; }

  constructor(private formBuilder: FormBuilder, private ApisService: ApisService, private router: Router) {
    this.triedSubmitting = false;
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required]]
    });
  }

  sendData() {
    console.log(this.loginForm.value);
    this.ApisService.loginuser(this.loginForm.value)
    .subscribe(data => { 
      console.log('login succesful');
       this.router.navigateByUrl('/dashboard');
       document.cookie=`user:${this.loginForm.value['username']};`
       }, err => { console.log('login failed'); })
  }
}
